/**
 * seed.js
 * ---------------------------------------------------------
 * Ejecuta el schema.sql (tablas) y luego inserta los datos
 * de prueba con las contraseñas YA encriptadas con bcrypt.
 *
 * Uso:
 *   node database/seed.js
 *
 * Requiere que las variables de entorno de conexión a la
 * base de datos (ver .env.example) estén configuradas.
 * ---------------------------------------------------------
 */

require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../src/config/db');

const usuariosSeed = [
  { nombre: 'Carlos Mendoza', correo: 'carlos@email.com', password: '123456', rol: 'admin' },
  { nombre: 'Ana García',     correo: 'ana@email.com',    password: '123456', rol: 'cliente' },
  { nombre: 'Luis Pérez',     correo: 'luis@email.com',   password: '123456', rol: 'cliente' },
];

const mesasSeed = [
  { numero: 1, capacidad: 2, disponible: true },
  { numero: 2, capacidad: 4, disponible: true },
  { numero: 3, capacidad: 6, disponible: false },
];

const reservacionesSeed = [
  { fecha: '2026-06-25', hora: '12:00', personas: 2, estado: 'confirmada', usuario_correo: 'ana@email.com',  mesa_numero: 1 },
  { fecha: '2026-06-25', hora: '14:00', personas: 4, estado: 'pendiente',  usuario_correo: 'luis@email.com', mesa_numero: 2 },
  { fecha: '2026-06-26', hora: '19:00', personas: 5, estado: 'pendiente',  usuario_correo: 'ana@email.com',  mesa_numero: 3 },
];

async function crearTablas() {
  const ddl = `
    DROP TABLE IF EXISTS reservaciones CASCADE;
    DROP TABLE IF EXISTS mesas CASCADE;
    DROP TABLE IF EXISTS usuarios CASCADE;

    CREATE TABLE usuarios (
        id          SERIAL PRIMARY KEY,
        nombre      VARCHAR(100) NOT NULL,
        correo      VARCHAR(100) NOT NULL UNIQUE,
        password    VARCHAR(255) NOT NULL,
        rol         VARCHAR(20) NOT NULL DEFAULT 'cliente' CHECK (rol IN ('cliente', 'admin')),
        created_at  TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE mesas (
        id          SERIAL PRIMARY KEY,
        numero      INT NOT NULL UNIQUE,
        capacidad   INT NOT NULL,
        disponible  BOOLEAN DEFAULT TRUE,
        created_at  TIMESTAMP DEFAULT NOW()
    );

    CREATE TABLE reservaciones (
        id          SERIAL PRIMARY KEY,
        fecha       DATE NOT NULL,
        hora        TIME NOT NULL,
        personas    INT NOT NULL,
        estado      VARCHAR(20) NOT NULL DEFAULT 'pendiente' CHECK (estado IN ('pendiente', 'confirmada', 'cancelada')),
        usuario_id  INT NOT NULL REFERENCES usuarios(id),
        mesa_id     INT NOT NULL REFERENCES mesas(id),
        created_at  TIMESTAMP DEFAULT NOW()
    );
  `;
  await pool.query(ddl);
  console.log('✅ Tablas creadas');
}

async function insertarUsuarios() {
  const ids = {};
  for (const u of usuariosSeed) {
    const hash = await bcrypt.hash(u.password, 10);
    const { rows } = await pool.query(
      `INSERT INTO usuarios (nombre, correo, password, rol) VALUES ($1,$2,$3,$4) RETURNING id, correo`,
      [u.nombre, u.correo, hash, u.rol]
    );
    ids[rows[0].correo] = rows[0].id;
  }
  console.log('✅ Usuarios insertados (passwords encriptadas con bcrypt)');
  return ids;
}

async function insertarMesas() {
  const ids = {};
  for (const m of mesasSeed) {
    const { rows } = await pool.query(
      `INSERT INTO mesas (numero, capacidad, disponible) VALUES ($1,$2,$3) RETURNING id, numero`,
      [m.numero, m.capacidad, m.disponible]
    );
    ids[rows[0].numero] = rows[0].id;
  }
  console.log('✅ Mesas insertadas');
  return ids;
}

async function insertarReservaciones(usuarioIds, mesaIds) {
  for (const r of reservacionesSeed) {
    await pool.query(
      `INSERT INTO reservaciones (fecha, hora, personas, estado, usuario_id, mesa_id)
       VALUES ($1,$2,$3,$4,$5,$6)`,
      [r.fecha, r.hora, r.personas, r.estado, usuarioIds[r.usuario_correo], mesaIds[r.mesa_numero]]
    );
  }
  console.log('✅ Reservaciones insertadas');
}

async function main() {
  try {
    await crearTablas();
    const usuarioIds = await insertarUsuarios();
    const mesaIds = await insertarMesas();
    await insertarReservaciones(usuarioIds, mesaIds);
    console.log('🎉 Seed completado con éxito');
  } catch (err) {
    console.error('❌ Error al ejecutar el seed:', err.message);
  } finally {
    await pool.end();
  }
}

main();
