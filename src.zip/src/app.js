const express = require('express');
const cors = require('cors');
const swaggerUi = require('swagger-ui-express');
const swaggerSpec = require('./swagger');

const authRoutes = require('./routes/auth.routes');
const mesasRoutes = require('./routes/mesas.routes');
const reservacionesRoutes = require('./routes/reservaciones.routes');

const app = express();

app.use(cors());
app.use(express.json());

// Documentación interactiva
app.use('/api-docs', swaggerUi.serve, swaggerUi.setup(swaggerSpec));

// Rutas principales
app.use('/api/auth', authRoutes);
app.use('/api/mesas', mesasRoutes);
app.use('/api/reservaciones', reservacionesRoutes);

// Endpoint raíz de verificación
app.get('/', (req, res) => {
  res.json({
    mensaje: 'API Restaurante funcionando correctamente 🍽️',
    documentacion: '/api-docs',
  });
});

// Manejo de rutas no encontradas
app.use((req, res) => {
  res.status(404).json({ error: 'Ruta no encontrada' });
});

// Manejador de errores genérico
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Error interno del servidor' });
});

module.exports = app;
