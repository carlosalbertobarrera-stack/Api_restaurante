const express = require('express');
const router = express.Router();
const {
  listarMesas,
  obtenerMesa,
  crearMesa,
  actualizarMesa,
  desactivarMesa,
} = require('../controllers/mesasController');
const verificarToken = require('../middleware/auth');
const verificarRol = require('../middleware/roles');

/**
 * @swagger
 * tags:
 *   name: Mesas
 *   description: Gestión del catálogo de mesas del restaurante
 */

/**
 * @swagger
 * /api/mesas:
 *   get:
 *     summary: Listar mesas (opcionalmente filtradas por disponibilidad)
 *     tags: [Mesas]
 *     parameters:
 *       - in: query
 *         name: disponible
 *         schema:
 *           type: boolean
 *         description: Filtrar por disponibilidad (true | false)
 *     responses:
 *       200:
 *         description: Lista de mesas
 */
router.get('/', listarMesas);

/**
 * @swagger
 * /api/mesas/{id}:
 *   get:
 *     summary: Obtener el detalle de una mesa
 *     tags: [Mesas]
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Detalle de la mesa
 *       404:
 *         description: Mesa no encontrada
 */
router.get('/:id', obtenerMesa);

/**
 * @swagger
 * /api/mesas:
 *   post:
 *     summary: Crear una nueva mesa (solo Admin)
 *     tags: [Mesas]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [numero, capacidad]
 *             properties:
 *               numero:
 *                 type: integer
 *                 example: 4
 *               capacidad:
 *                 type: integer
 *                 example: 4
 *               disponible:
 *                 type: boolean
 *                 example: true
 *     responses:
 *       201:
 *         description: Mesa creada con éxito
 *       403:
 *         description: Acceso denegado (requiere rol admin)
 */
router.post('/', verificarToken, verificarRol('admin'), crearMesa);

/**
 * @swagger
 * /api/mesas/{id}:
 *   put:
 *     summary: Actualizar los datos de una mesa (solo Admin)
 *     tags: [Mesas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             properties:
 *               numero:
 *                 type: integer
 *               capacidad:
 *                 type: integer
 *               disponible:
 *                 type: boolean
 *     responses:
 *       200:
 *         description: Mesa actualizada con éxito
 *       404:
 *         description: Mesa no encontrada
 */
router.put('/:id', verificarToken, verificarRol('admin'), actualizarMesa);

/**
 * @swagger
 * /api/mesas/{id}:
 *   delete:
 *     summary: Desactivar una mesa (soft delete, solo Admin)
 *     tags: [Mesas]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Mesa desactivada con éxito
 *       404:
 *         description: Mesa no encontrada
 */
router.delete('/:id', verificarToken, verificarRol('admin'), desactivarMesa);

module.exports = router;
