const express = require('express');
const router = express.Router();
const {
  crearReservacion,
  misReservaciones,
  listarReservaciones,
  cambiarEstado,
  cancelarReservacion,
} = require('../controllers/reservacionesController');
const verificarToken = require('../middleware/auth');
const verificarRol = require('../middleware/roles');

/**
 * @swagger
 * tags:
 *   name: Reservaciones
 *   description: Creación y gestión de reservaciones de mesas
 */

/**
 * @swagger
 * /api/reservaciones:
 *   post:
 *     summary: Crear una reservación (valida disponibilidad de la mesa, solo Cliente)
 *     tags: [Reservaciones]
 *     security:
 *       - bearerAuth: []
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [mesa_id, fecha, hora, personas]
 *             properties:
 *               mesa_id:
 *                 type: integer
 *                 example: 1
 *               fecha:
 *                 type: string
 *                 format: date
 *                 example: "2026-07-10"
 *               hora:
 *                 type: string
 *                 example: "19:00"
 *               personas:
 *                 type: integer
 *                 example: 2
 *     responses:
 *       201:
 *         description: Reservación creada con éxito
 *       409:
 *         description: La mesa ya está reservada en esa fecha y hora, o no está disponible
 */
router.post('/', verificarToken, verificarRol('cliente'), crearReservacion);

/**
 * @swagger
 * /api/reservaciones/mis:
 *   get:
 *     summary: Ver mis propias reservaciones (solo Cliente)
 *     tags: [Reservaciones]
 *     security:
 *       - bearerAuth: []
 *     responses:
 *       200:
 *         description: Lista de reservaciones del usuario autenticado
 */
router.get('/mis', verificarToken, verificarRol('cliente'), misReservaciones);

/**
 * @swagger
 * /api/reservaciones:
 *   get:
 *     summary: Ver todas las reservaciones con filtros (solo Admin)
 *     tags: [Reservaciones]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: query
 *         name: estado
 *         schema:
 *           type: string
 *           enum: [pendiente, confirmada, cancelada]
 *       - in: query
 *         name: fecha
 *         schema:
 *           type: string
 *           format: date
 *       - in: query
 *         name: mesa_id
 *         schema:
 *           type: integer
 *       - in: query
 *         name: usuario_id
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Lista de todas las reservaciones
 */
router.get('/', verificarToken, verificarRol('admin'), listarReservaciones);

/**
 * @swagger
 * /api/reservaciones/{id}/estado:
 *   put:
 *     summary: Cambiar el estado de una reservación (solo Admin)
 *     tags: [Reservaciones]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             type: object
 *             required: [estado]
 *             properties:
 *               estado:
 *                 type: string
 *                 enum: [pendiente, confirmada, cancelada]
 *     responses:
 *       200:
 *         description: Estado actualizado con éxito
 *       404:
 *         description: Reservación no encontrada
 */
router.put('/:id/estado', verificarToken, verificarRol('admin'), cambiarEstado);

/**
 * @swagger
 * /api/reservaciones/{id}:
 *   delete:
 *     summary: Cancelar la propia reservación (solo Cliente, dueño de la reservación)
 *     tags: [Reservaciones]
 *     security:
 *       - bearerAuth: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Reservación cancelada con éxito
 *       403:
 *         description: No puedes cancelar una reservación que no es tuya
 *       404:
 *         description: Reservación no encontrada
 */
router.delete('/:id', verificarToken, verificarRol('cliente'), cancelarReservacion);

module.exports = router;
