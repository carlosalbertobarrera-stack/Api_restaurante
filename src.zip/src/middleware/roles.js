/**
 * Middleware de autorización por rol.
 * Uso: verificarRol('admin') o verificarRol('admin', 'cliente')
 * Debe usarse SIEMPRE después de verificarToken, ya que depende de req.usuario.
 */
function verificarRol(...rolesPermitidos) {
  return (req, res, next) => {
    if (!req.usuario) {
      return res.status(401).json({ error: 'No autenticado' });
    }

    if (!rolesPermitidos.includes(req.usuario.rol)) {
      return res.status(403).json({
        error: `Acceso denegado. Se requiere rol: ${rolesPermitidos.join(' o ')}`,
      });
    }

    next();
  };
}

module.exports = verificarRol;
