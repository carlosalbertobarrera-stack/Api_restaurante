const swaggerJsdoc = require('swagger-jsdoc');

const options = {
  definition: {
    openapi: '3.0.0',
    info: {
      title: 'API Restaurante - Reservaciones',
      version: '1.0.0',
      description:
        'API REST para gestión de reservaciones de un restaurante. Incluye autenticación ' +
        'JWT, encriptación de contraseñas con bcrypt, control de acceso por roles ' +
        '(cliente / admin) y validación de disponibilidad de mesas.',
      contact: {
        name: 'Carlos Mendoza',
      },
    },
    servers: [
      {
        url: process.env.API_BASE_URL || 'http://localhost:3000',
        description: 'Servidor',
      },
    ],
    components: {
      securitySchemes: {
        bearerAuth: {
          type: 'http',
          scheme: 'bearer',
          bearerFormat: 'JWT',
          description: 'Ingresa el token JWT obtenido en /api/auth/login',
        },
      },
    },
  },
  apis: ['./src/routes/*.js'],
};

module.exports = swaggerJsdoc(options);
