const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const pool = require('../config/db');

const SALT_ROUNDS = 10;

/**
 * POST /api/auth/register
 * Registro público — siempre crea el usuario con rol "cliente".
 */
async function register(req, res) {
  try {
    const { nombre, correo, password } = req.body;

    if (!nombre || !correo || !password) {
      return res.status(400).json({ error: 'nombre, correo y password son obligatorios' });
    }

    if (password.length < 6) {
      return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres' });
    }

    const existente = await pool.query('SELECT id FROM usuarios WHERE correo = $1', [correo]);
    if (existente.rows.length > 0) {
      return res.status(409).json({ error: 'Ya existe un usuario con ese correo' });
    }

    const hash = await bcrypt.hash(password, SALT_ROUNDS);

    const { rows } = await pool.query(
      `INSERT INTO usuarios (nombre, correo, password, rol)
       VALUES ($1, $2, $3, 'cliente')
       RETURNING id, nombre, correo, rol, created_at`,
      [nombre, correo, hash]
    );

    return res.status(201).json({ mensaje: 'Usuario registrado con éxito', usuario: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al registrar el usuario' });
  }
}

/**
 * POST /api/auth/login
 * Valida credenciales y devuelve un JWT firmado.
 */
async function login(req, res) {
  try {
    const { correo, password } = req.body;

    if (!correo || !password) {
      return res.status(400).json({ error: 'correo y password son obligatorios' });
    }

    const { rows } = await pool.query('SELECT * FROM usuarios WHERE correo = $1', [correo]);
    const usuario = rows[0];

    if (!usuario) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const passwordValido = await bcrypt.compare(password, usuario.password);
    if (!passwordValido) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const token = jwt.sign(
      { id: usuario.id, correo: usuario.correo, rol: usuario.rol, nombre: usuario.nombre },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '2h' }
    );

    return res.json({
      mensaje: 'Login exitoso',
      token,
      usuario: { id: usuario.id, nombre: usuario.nombre, correo: usuario.correo, rol: usuario.rol },
    });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al iniciar sesión' });
  }
}

/**
 * GET /api/auth/perfil
 * Requiere token. Devuelve los datos del usuario autenticado.
 */
async function perfil(req, res) {
  try {
    const { rows } = await pool.query(
      'SELECT id, nombre, correo, rol, created_at FROM usuarios WHERE id = $1',
      [req.usuario.id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Usuario no encontrado' });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al obtener el perfil' });
  }
}

module.exports = { register, login, perfil };
