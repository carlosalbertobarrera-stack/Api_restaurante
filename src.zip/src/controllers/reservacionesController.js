const pool = require('../config/db');

/**
 * POST /api/reservaciones
 * Solo Cliente. Valida que la mesa exista, esté disponible y no tenga
 * ya una reservación activa (pendiente o confirmada) en la misma fecha y hora.
 */
async function crearReservacion(req, res) {
  try {
    const { mesa_id, fecha, hora, personas } = req.body;
    const usuario_id = req.usuario.id;

    if (!mesa_id || !fecha || !hora || !personas) {
      return res.status(400).json({ error: 'mesa_id, fecha, hora y personas son obligatorios' });
    }

    const mesaResult = await pool.query('SELECT * FROM mesas WHERE id = $1', [mesa_id]);
    if (mesaResult.rows.length === 0) {
      return res.status(404).json({ error: 'La mesa indicada no existe' });
    }

    const mesa = mesaResult.rows[0];

    if (!mesa.disponible) {
      return res.status(409).json({ error: 'La mesa no está disponible actualmente' });
    }

    if (personas > mesa.capacidad) {
      return res.status(400).json({
        error: `La mesa ${mesa.numero} tiene capacidad para ${mesa.capacidad} personas, no ${personas}`,
      });
    }

    // Validar que no exista otra reservación activa para esa mesa, fecha y hora
    const conflicto = await pool.query(
      `SELECT id FROM reservaciones
       WHERE mesa_id = $1 AND fecha = $2 AND hora = $3
         AND estado IN ('pendiente', 'confirmada')`,
      [mesa_id, fecha, hora]
    );

    if (conflicto.rows.length > 0) {
      return res.status(409).json({ error: 'La mesa ya está reservada en esa fecha y hora' });
    }

    const { rows } = await pool.query(
      `INSERT INTO reservaciones (fecha, hora, personas, estado, usuario_id, mesa_id)
       VALUES ($1, $2, $3, 'pendiente', $4, $5) RETURNING *`,
      [fecha, hora, personas, usuario_id, mesa_id]
    );

    return res.status(201).json({ mensaje: 'Reservación creada con éxito', reservacion: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al crear la reservación' });
  }
}

/**
 * GET /api/reservaciones/mis
 * Solo Cliente. Devuelve únicamente las reservaciones del usuario autenticado.
 */
async function misReservaciones(req, res) {
  try {
    const { rows } = await pool.query(
      `SELECT r.*, m.numero AS mesa_numero, m.capacidad AS mesa_capacidad
       FROM reservaciones r
       JOIN mesas m ON m.id = r.mesa_id
       WHERE r.usuario_id = $1
       ORDER BY r.fecha DESC, r.hora DESC`,
      [req.usuario.id]
    );
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al obtener tus reservaciones' });
  }
}

/**
 * GET /api/reservaciones
 * Solo Admin. Soporta filtros: ?estado=&fecha=&mesa_id=&usuario_id=
 */
async function listarReservaciones(req, res) {
  try {
    const { estado, fecha, mesa_id, usuario_id } = req.query;
    const condiciones = [];
    const valores = [];

    if (estado) {
      valores.push(estado);
      condiciones.push(`r.estado = $${valores.length}`);
    }
    if (fecha) {
      valores.push(fecha);
      condiciones.push(`r.fecha = $${valores.length}`);
    }
    if (mesa_id) {
      valores.push(mesa_id);
      condiciones.push(`r.mesa_id = $${valores.length}`);
    }
    if (usuario_id) {
      valores.push(usuario_id);
      condiciones.push(`r.usuario_id = $${valores.length}`);
    }

    let query = `
      SELECT r.*, u.nombre AS usuario_nombre, u.correo AS usuario_correo,
             m.numero AS mesa_numero
      FROM reservaciones r
      JOIN usuarios u ON u.id = r.usuario_id
      JOIN mesas m ON m.id = r.mesa_id
    `;

    if (condiciones.length > 0) {
      query += ' WHERE ' + condiciones.join(' AND ');
    }

    query += ' ORDER BY r.fecha DESC, r.hora DESC';

    const { rows } = await pool.query(query, valores);
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al listar reservaciones' });
  }
}

/**
 * PUT /api/reservaciones/:id/estado
 * Solo Admin. Cambia el estado de una reservación (pendiente | confirmada | cancelada).
 */
async function cambiarEstado(req, res) {
  try {
    const { id } = req.params;
    const { estado } = req.body;

    const estadosValidos = ['pendiente', 'confirmada', 'cancelada'];
    if (!estado || !estadosValidos.includes(estado)) {
      return res.status(400).json({ error: `estado debe ser uno de: ${estadosValidos.join(', ')}` });
    }

    const { rows } = await pool.query(
      `UPDATE reservaciones SET estado = $1 WHERE id = $2 RETURNING *`,
      [estado, id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Reservación no encontrada' });
    }

    return res.json({ mensaje: 'Estado actualizado con éxito', reservacion: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al cambiar el estado' });
  }
}

/**
 * DELETE /api/reservaciones/:id
 * Solo Cliente, y únicamente sobre sus propias reservaciones.
 * Cancela (no borra físicamente) la reservación.
 */
async function cancelarReservacion(req, res) {
  try {
    const { id } = req.params;

    const actual = await pool.query('SELECT * FROM reservaciones WHERE id = $1', [id]);
    if (actual.rows.length === 0) {
      return res.status(404).json({ error: 'Reservación no encontrada' });
    }

    if (actual.rows[0].usuario_id !== req.usuario.id) {
      return res.status(403).json({ error: 'No puedes cancelar una reservación que no es tuya' });
    }

    const { rows } = await pool.query(
      `UPDATE reservaciones SET estado = 'cancelada' WHERE id = $1 RETURNING *`,
      [id]
    );

    return res.json({ mensaje: 'Reservación cancelada con éxito', reservacion: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al cancelar la reservación' });
  }
}

module.exports = {
  crearReservacion,
  misReservaciones,
  listarReservaciones,
  cambiarEstado,
  cancelarReservacion,
};
