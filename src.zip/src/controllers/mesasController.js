const pool = require('../config/db');

/**
 * GET /api/mesas
 * Público. Soporta ?disponible=true|false
 */
async function listarMesas(req, res) {
  try {
    const { disponible } = req.query;
    let query = 'SELECT * FROM mesas';
    const params = [];

    if (disponible !== undefined) {
      params.push(disponible === 'true');
      query += ' WHERE disponible = $1';
    }

    query += ' ORDER BY numero ASC';

    const { rows } = await pool.query(query, params);
    return res.json(rows);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al listar mesas' });
  }
}

/**
 * GET /api/mesas/:id
 * Público.
 */
async function obtenerMesa(req, res) {
  try {
    const { id } = req.params;
    const { rows } = await pool.query('SELECT * FROM mesas WHERE id = $1', [id]);

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Mesa no encontrada' });
    }

    return res.json(rows[0]);
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al obtener la mesa' });
  }
}

/**
 * POST /api/mesas
 * Solo Admin.
 */
async function crearMesa(req, res) {
  try {
    const { numero, capacidad, disponible } = req.body;

    if (numero === undefined || capacidad === undefined) {
      return res.status(400).json({ error: 'numero y capacidad son obligatorios' });
    }

    const existente = await pool.query('SELECT id FROM mesas WHERE numero = $1', [numero]);
    if (existente.rows.length > 0) {
      return res.status(409).json({ error: `Ya existe una mesa con el número ${numero}` });
    }

    const { rows } = await pool.query(
      `INSERT INTO mesas (numero, capacidad, disponible) VALUES ($1, $2, $3) RETURNING *`,
      [numero, capacidad, disponible !== undefined ? disponible : true]
    );

    return res.status(201).json({ mensaje: 'Mesa creada con éxito', mesa: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al crear la mesa' });
  }
}

/**
 * PUT /api/mesas/:id
 * Solo Admin.
 */
async function actualizarMesa(req, res) {
  try {
    const { id } = req.params;
    const { numero, capacidad, disponible } = req.body;

    const actual = await pool.query('SELECT * FROM mesas WHERE id = $1', [id]);
    if (actual.rows.length === 0) {
      return res.status(404).json({ error: 'Mesa no encontrada' });
    }

    const mesa = actual.rows[0];

    const { rows } = await pool.query(
      `UPDATE mesas SET numero = $1, capacidad = $2, disponible = $3 WHERE id = $4 RETURNING *`,
      [
        numero !== undefined ? numero : mesa.numero,
        capacidad !== undefined ? capacidad : mesa.capacidad,
        disponible !== undefined ? disponible : mesa.disponible,
        id,
      ]
    );

    return res.json({ mensaje: 'Mesa actualizada con éxito', mesa: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al actualizar la mesa' });
  }
}

/**
 * DELETE /api/mesas/:id
 * Solo Admin. Soft delete: marca disponible = false en vez de borrar el registro.
 */
async function desactivarMesa(req, res) {
  try {
    const { id } = req.params;

    const { rows } = await pool.query(
      `UPDATE mesas SET disponible = false WHERE id = $1 RETURNING *`,
      [id]
    );

    if (rows.length === 0) {
      return res.status(404).json({ error: 'Mesa no encontrada' });
    }

    return res.json({ mensaje: 'Mesa desactivada (soft delete)', mesa: rows[0] });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: 'Error interno al desactivar la mesa' });
  }
}

module.exports = { listarMesas, obtenerMesa, crearMesa, actualizarMesa, desactivarMesa };
